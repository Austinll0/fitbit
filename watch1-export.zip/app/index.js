import clock from "clock";
import * as document from "document";
import { preferences } from "user-settings";
import * as util from "../common/utils";

// Update the clock every second
clock.granularity = "seconds";
let sHand = document.getElementById("secondHand");
let mHand = document.getElementById("minuteHand");
let hHand = document.getElementById("hourHand");
var months = [ "January", "February", "March", "April", "May", "June", 
           "July", "August", "September", "October", "November", "December" ];

// Get a handle on the <text> element
const myLabel = document.getElementById("myLabel");

// Returns an angle (0-360) for the current hour in the day, including minutes
function hoursToAngle(hours, minutes) {
  let hourAngle = (360 / 12) * hours;
  let minAngle = (360 / 12 / 60) * minutes;
  return hourAngle + minAngle;
}

// Returns an angle (0-360) for minutes
function minutesToAngle(minutes) {
  return (360 / 60) * minutes;
}

// Returns an angle (0-360) for seconds
function secondsToAngle(seconds) {
  return (360 / 60) * seconds;
}


// Update the <text> element every tick with the current time
clock.ontick = (evt) => {
  let today = evt.date;
  let hours = today.getHours();
  let mins = today.getMinutes();
  let secs = today.getSeconds();
  let month = months[today.getMonth()];
  let day = today.getDate();
  let a = secondsToAngle(secs);
  //myLabel.text = `${hours}:${mins}:${secs}`;
  myLabel.text = `${month} ${day}`;
  sHand.groupTransform.rotate.angle = a;
  mHand.groupTransform.rotate.angle = a+30;
  hHand.groupTransform.rotate.angle = a+60;
}
